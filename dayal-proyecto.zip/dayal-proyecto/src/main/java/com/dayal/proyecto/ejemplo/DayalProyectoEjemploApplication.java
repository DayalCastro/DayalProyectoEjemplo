package com.dayal.proyecto.ejemplo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DayalProyectoEjemploApplication {

	public static void main(String[] args) {
		SpringApplication.run(DayalProyectoEjemploApplication.class, args);
	}

}

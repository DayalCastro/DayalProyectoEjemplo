package com.dayal.proyecto.ejemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DayalProyectoEjemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
